# Ailunce-HD1-CP
Ailunce HD1 DMR Radio Code Plug - OHIO - WORK IN PROGRESS
This repository contains a base DMR Code Plug for the Ailunce HD1 radio. 

The user is expected to add their Radio Information, Call Sign with DMR ID and create any special Zones for scanning.

Additionally two CSV files are provided so that you can import this code plug into the Ailunce CPS software.

The XLSM and CSV files were used in conjunction with the Ailunce Code Plug editing software. 
The latest upload has the following chages:
  1. Corrected PARROT - AKA Echo to be a Private Call not a Group Call. The latter does not echo your test.
  2. Added more OS or OPEN Spot (Shark RF) connections. 
  3. The following DM repeaters have been checked at least at the level of Echo and Tac-310:
    a. Kent Ohio
    b. Copley Ohio
    c. Akron Ohio (not AK2)
    d. Mantua Ohio
  4. The 4000 Disconnet and 5000 Status groups are added and experimental.
  
If you try this and have suggestions please email me at vbfb1953@gmail.com. If you try this and confirm a repeater an email would be appreciated. I will add to the list of tested repeaters here.

Further info to follow...

